export interface Szalon {
    cim: string;
    nyitvatartas: string;
    email: string;
    telefonszam: string;
  }
  