export interface Foglalas {
    id: number;
    datum: string;
    ido: string;
    vendegNev: string;
    tetovaloId: number;
  }
  