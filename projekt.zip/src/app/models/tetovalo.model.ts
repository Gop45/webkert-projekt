export interface Tetovalo {
    id: number;
    nev: string;
    stilus: string;
    tapasztalatEv: number;
  }
  