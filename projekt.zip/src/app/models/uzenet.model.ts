export interface Uzenet {
    nev: string;
    email: string;
    szoveg: string;
    datum: Date;
  }
  